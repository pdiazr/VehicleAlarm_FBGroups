package es.gpsou.antirrobo;

import android.nfc.NfcAdapter;
import android.nfc.Tag;
import android.nfc.tech.IsoDep;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.widget.TextView;

import java.io.IOException;

public class NFCPairing extends AppCompatActivity implements NfcAdapter.ReaderCallback {

    private static final byte[] CLA_INS_P1_P2 = { 0x00, (byte)0xA4, 0x04, 0x00 };
    private static final byte[] AID_ANDROID = { (byte)0xF0, 0x01, 0x02, 0x03, 0x04, 0x05, 0x06 };

    NfcAdapter nfcAdapter=null;

    private byte[] createSelectAidApdu(byte[] aid) {
        byte[] result = new byte[6 + aid.length];
        System.arraycopy(CLA_INS_P1_P2, 0, result, 0, CLA_INS_P1_P2.length);
        result[4] = (byte)aid.length;
        System.arraycopy(aid, 0, result, 5, aid.length);
        result[result.length - 1] = 0;
        return result;
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_nfcpairing);

        nfcAdapter=NfcAdapter.getDefaultAdapter(this);
    }


    @Override
    public void onResume() {
        super.onResume();
        nfcAdapter.enableReaderMode(this, this, NfcAdapter.FLAG_READER_NFC_A | NfcAdapter.FLAG_READER_SKIP_NDEF_CHECK,
                null);
    }

    @Override
    public void onPause() {
        super.onPause();
        nfcAdapter.disableReaderMode(this);
    }

    @Override
    public void onTagDiscovered(Tag tag) {

        byte[] response;
        IsoDep isoDep = IsoDep.get(tag);

        try {
            isoDep.connect();
            response=isoDep.transceive(createSelectAidApdu(AID_ANDROID));
            response=isoDep.transceive("Mensaje de prueba".getBytes());
            final byte[] finalResponse = response;
            runOnUiThread(new Runnable() {
                @Override
                public void run() {
                    TextView texto=(TextView)findViewById(R.id.textView);
                    texto.setText(new String(finalResponse));
                }
            });

        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}
