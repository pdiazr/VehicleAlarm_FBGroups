package es.gpsou.antirrobo;

import android.bluetooth.BluetoothAdapter;
import android.bluetooth.BluetoothDevice;
import android.bluetooth.BluetoothSocket;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.hardware.Sensor;
import android.hardware.SensorEvent;
import android.hardware.SensorEventListener;
import android.hardware.SensorManager;
import android.media.MediaPlayer;
import android.media.RingtoneManager;
import android.net.Uri;
import android.os.AsyncTask;
import android.os.Bundle;
import android.os.PowerManager;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.TextView;

import java.io.IOException;
import java.util.UUID;

public class MainActivity extends AppCompatActivity implements SensorEventListener {
    private static SensorManager mSensorManager;
    private PowerManager.WakeLock wl=null;
    private static Sensor mSensor;
    private float lastX=0, lastY=0, lastZ=0;

    @Override
    protected void onDestroy() {
        super.onDestroy();

//        Intent i = new Intent(Intent.ACTION_VIEW, Uri.parse("http://www.gpsou.es/mas.mp3"));
//        startActivity(i);
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        mSensorManager = (SensorManager) getSystemService(SENSOR_SERVICE);
        mSensor = mSensorManager.getDefaultSensor(Sensor.TYPE_ACCELEROMETER);

        PowerManager pm=(PowerManager)getSystemService(POWER_SERVICE);
        wl=pm.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, this.getLocalClassName());
        wl.acquire();


        Intent intent = new Intent(this, MyFirebaseInstanceIdService.class);
        startService(intent);

        mSensorManager.registerListener(this, mSensor, SensorManager.SENSOR_DELAY_NORMAL);

        IntentFilter filter = new IntentFilter();
        filter.addAction("android.intent.action.SCREEN_OFF");
        this.registerReceiver(new wakeSoC(), filter, "com.google.android.c2dm.permission.SEND", null);
    }



    @Override
    public void onSensorChanged(SensorEvent event) {
        TextView texto;
        float accX, accY, accZ;
        accX=event.values[0];
        accY=event.values[1];
        accZ=event.values[2];

        float diff=Math.abs(accX-lastX)+Math.abs(accY-lastY)+Math.abs(accZ-lastZ);
        lastX=accX;
        lastY=accY;
        lastZ=accZ;

        texto=(TextView)findViewById(R.id.textView1);
        texto.setText(Float.toString(accX));
        texto=(TextView)findViewById(R.id.textView2);
        texto.setText(Float.toString(accY));
        texto=(TextView)findViewById(R.id.textView3);
        texto.setText(Float.toString(accZ));

        texto=(TextView)findViewById(R.id.textView4);
//        texto.setText(Float.toString(diff));
        if(diff>1.0f){
            new playAlert().execute();
        }
    }

    @Override
    public void onAccuracyChanged(Sensor sensor, int accuracy) {

    }


    public void pairing(View view) {
        Intent intent = new Intent(this, NFCPairing.class);
        startActivity(intent);
    }

    public void btSearch(View view) {
        BluetoothAdapter btAdapter=BluetoothAdapter.getDefaultAdapter();

        BluetoothDevice bt=btAdapter.getRemoteDevice("88:28:B3:6C:23:7B");
        try {
            BluetoothSocket socket=bt.createRfcommSocketToServiceRecord(new UUID(0L, 0L));
            btAdapter.cancelDiscovery();
            socket.connect();
        } catch (IOException e) {
            e.printStackTrace();
        }

        TextView texto=(TextView)findViewById(R.id.textView4);
        texto.setText("BLUETOOTH SOCKET");
    }

    private class playAlert extends AsyncTask <Void, Void, Void> implements MediaPlayer.OnCompletionListener {

        @Override
        protected Void doInBackground(Void... params) {
            Uri notification = RingtoneManager.getDefaultUri(RingtoneManager.TYPE_NOTIFICATION);
            MediaPlayer mp = MediaPlayer.create(getApplicationContext(), notification);
            mp.setOnCompletionListener(this);
            mp.start();

            return null;
        }

        @Override
        public void onCompletion(MediaPlayer mp) {
            mp.release();
        }

    }

    public  class wakeSoC extends BroadcastReceiver {
        public wakeSoC() {
        }

        @Override
        public void onReceive(Context context, Intent intent) {
            TextView texto=(TextView)findViewById(R.id.textView4);
            texto.setText("SCREEN OFF INTENT");

            new playAlert().execute();

            mSensorManager.unregisterListener(MainActivity.this);
            mSensorManager.registerListener(MainActivity.this, mSensor, SensorManager.SENSOR_DELAY_NORMAL);

        }
    }
}
